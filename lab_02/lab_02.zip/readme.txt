Dzień dobry,
w archiwum lab_01.zip przesyłam również zaległe pliki z pierwszego laboratorium.

Pozdrawiam,
Paweł Młodkowski
